FileName:
	1.helpers.js
	2.csce322a02p01.js
	3.csce322a02p02.js
Extension:
	1. 3 calendar days
Assumptions:
	1. The board state is initialized as outlined within the referenced draught 
regulations.
	2. Move list begins from the point where no pieces have been moved.
	3. Some Error checking should be instantiated.
	4. Code does contain possible jump moves but had difficulty combining arrays
Sources:
	1. Duff, Josh. Online Consultation.
	2. "HTML." W3Schools Online Web Tutorials. N.p., n.d. Web. 31 July 2014.