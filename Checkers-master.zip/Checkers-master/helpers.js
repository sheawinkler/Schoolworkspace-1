/**
 * 
 */

module.exports = {
    readMoves: readMoves,
    kingSingleCheck: kingSingleCheck,
    regularRedMove: regularRedMove,
    kingJump: kingJump,
    blackJump: blackJump,
    redJump: redJump,
    regularBlackMove: regularBlackMove,
    displayMoves: displayMoves,
    xyToSingle: xyToSingle,
    initializeTable: initializeTable,
    convertToCoordinate: convertToCoordinate,
    movePieces: movePieces
}

function isRedJumped(redMen, blackMen, xCord,yCord){
    for(var t=0; t< redMen.length;t++) {
        if ( xCord == redMen[t].x &&  yCord == redMen[t].y) {
            return true;
        }

    }
    return false;
}

function isBlackJumped(redMen, blackMen, xCord,yCord){
    for(var t=0; t< blackMen.length;t++) {
        if ( xCord == blackMen[t].x &&  yCord == blackMen[t].y) {
            return true;
        }

    }
    return false;
}


function kingJump(blackMen,redMen,checkerPiece,indexing){
    var kingMoves=[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object();
    var secondCoordinate = new Object();
    var thirdCoordinate = new Object();
    var fourthCoordinate = new Object();
    //checking whether on even or odd row
        //Checking UP Diagonal Left
        if(isEmpty(xPos-1,yPos-2,blackMen,redMen)){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos-2;
            kingMoves.push(newCoordinate);
        }
        //check UP Diagonal Right
        if(isEmpty(xPos+1,yPos-2,blackMen,redMen)){
            secondCoordinate.x= xPos+1;
            secondCoordinate.y= yPos-2;
            kingMoves.push(secondCoordinate);
        }
        //Checking Down Diagonal Left
        if(isEmpty(xPos-1,yPos+2,blackMen,redMen)){
            thirdCoordinate.x= xPos-1;
            thirdCoordinate.y= yPos+2;
            kingMoves.push(thirdCoordinate);
        }
        //Checking Down Diagonal Right
        if(isEmpty(xPos+1,yPos+2,blackMen,redMen)){
            fourthCoordinate.x= xPos+1;
            fourthCoordinate.y= yPos+2;
            kingMoves.push(fourthCoordinate);
        }
    return kingMoves;
}

function blackJump(blackMen,redMen,checkerPiece,indexing){
    var blackMoves =[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object();
    var secondCoordinate = new Object();

        if(isEmpty(xPos-1,yPos-2,blackMen,redMen)==true && isRedJumped(redMen, blackMen, xPos-1,yPos-1) ==true){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos-2;
            blackMoves.push(newCoordinate);
        }


        if(isEmpty(xPos+1,yPos-2,blackMen,redMen ==true) && isRedJumped(redMen, blackMen, xPos,yPos-1)== true) {
                secondCoordinate.x = xPos + 1;
                secondCoordinate.y = yPos - 2;
                blackMoves.push(secondCoordinate);
        }



    return blackMoves;
}


function redJump(blackMen,redMen,checkerPiece,indexing){
    var redMoves =[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object() ;
    var secondCoordinate = new Object();

        if(isEmpty(xPos-1,yPos+2,blackMen,redMen)==true && isBlackJumped(redMen, blackMen, xPos-1,yPos+1) == true){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos+2;
            redMoves.push(newCoordinate);
        }
        if(isEmpty(xPos+1,yPos+2,blackMen,redMen)==true && isBlackJumped(redMen, blackMen, xPos+1,yPos+1) == true){
            secondCoordinate.x= xPos+1;
            secondCoordinate.y= yPos+2;
            redMoves.push(secondCoordinate);
        }



    return redMoves
}





//container is an object with three properties redMen, blackMen, finalCoordinates
function initializeTable(moves){

        var redMen =
            [
                {x:1,y:1,king:false,red:true},{x:2,y:1,king:false,red:true},{x:3,y:1,king:false,red:true},{x:4,y:1,king:false,red:true},{x:5,y:1,king:false,red:true},
                {x:1,y:2,king:false,red:true},{x:2,y:2,king:false,red:true},{x:3,y:2,king:false,red:true},{x:4,y:2,king:false,red:true},{x:5,y:2,king:false,red:true},
                {x:1,y:3,king:false,red:true},{x:2,y:3,king:false,red:true},{x:3,y:3,king:false,red:true},{x:4,y:3,king:false,red:true},{x:5,y:3,king:false,red:true},
                {x:1,y:4,king:false,red:true},{x:2,y:4,king:false,red:true},{x:3,y:4,king:false,red:true},{x:4,y:4,king:false,red:true},{x:5,y:4,king:false,red:true}
            ];

        var blackMen =
            [
                {x:1,y:7,king:false},{x:2,y:7,king:false},{x:3,y:7,king:false},{x:4,y:7,king:false},{x:5,y:7,king:false},
                {x:1,y:8,king:false},{x:2,y:8,king:false},{x:3,y:8,king:false},{x:4,y:8,king:false},{x:5,y:8,king:false},
                {x:1,y:9,king:false},{x:2,y:9,king:false},{x:3,y:9,king:false},{x:4,y:9,king:false},{x:5,y:9,king:false},
                {x:1,y:10,king:false},{x:2,y:10,king:false},{x:3,y:10,king:false},{x:4,y:10,king:false},{x:5,y:10,king:false}
            ];

            //converting the 2d matrix to 2 arrays of coordinates
            var finalCoordinates =  convertToCoordinate(moves);
            var container = {redMen: redMen, blackMen: blackMen, finalCoordinates: finalCoordinates};
    return container;
}






//Check what type of move it is by location and move piece.  Black down and Red up
function makeMove(redMen, blackMen, finalCoordinates, position){

    var even = evenOrOdd(finalCoordinates, position);
    var redChecker = isRedChecker(redMen, blackMen, finalCoordinates, position);
    if(redChecker == true) {
        // Here is where the instantiation of even is not really necessary
        if (even == true) {
            //If statements not currently useful as input moves have been error-checked but can be in future versions
            //Using it later to code the specific move of an individual red piece located in a corner
            if (finalCoordinates.moveFromCoordinate[position].coordinate.x == 1) {
                for(var n=0;n<redMen.length;n++){
                    //if a match is found in the red checker set
                    if(finalCoordinates.moveFromCoordinate[position].coordinate.x == redMen[n].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == redMen[n].y){
                        //if I jumped a guy, delete him
                        if( (finalCoordinates.moveToCoordinate[position].coordinate.y == finalCoordinates.moveFromCoordinate[position].coordinate.y +2) &&
                            ((finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x+1)||
                                (finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x-1)))
                        {
                           //Deleting Captured Men
                            var direction = finalCoordinates.moveToCoordinate[position].coordinate.x - finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            var xLocationRemoving;
                            var yLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.y +1;
                            if(direction>0){
                                //Direction is to right
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            }else{
                                //Direction is to left
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x -1;
                            }
                            //Maybe add another if statement checking whether there is actually a piece in the location getting jumped
                            //Finally deleting the blackChecker

                            var toRemove = blackMen.reduce(function(foundIndex, piece, index) {
                                if (!foundIndex && piece.x === xLocationRemoving && piece.y === yLocationRemoving) {
                                    return index
                                } else {
                                    return foundIndex
                                }
                            }, null)

                            if (toRemove != null) {
                                blackMen.splice(toRemove, 1)
                            }


                        }
                        //Finally completing move
                        if(finalCoordinates.moveToCoordinate[position].coordinate.y == 10){
                            redMen[n].king = true;
                        }
                        redMen[n].x=finalCoordinates.moveToCoordinate[position].coordinate.x;
                        redMen[n].y=finalCoordinates.moveToCoordinate[position].coordinate.y;
                        break;
                    }
                }
                //if moving from a even y coordinate and x!=1
            }else{
                for(var n=0;n<redMen.length;n++){
                    //if a match is found in the red checker set
                    if(finalCoordinates.moveFromCoordinate[position].coordinate.x == redMen[n].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == redMen[n].y){
                        //if I jumped a guy, delete him
                        if( (finalCoordinates.moveToCoordinate[position].coordinate.y == finalCoordinates.moveFromCoordinate[position].coordinate.y +2) &&
                            ((finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x+1)||
                                (finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x-1)))
                        {
                            //Deleting Captured Men
                            var direction = finalCoordinates.moveToCoordinate[position].coordinate.x - finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            var xLocationRemoving;
                            var yLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.y +1;
                            if(direction>0){
                                //Direction is to right
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            }else{
                                //Direction is to left
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x -1;
                            }
                            //Maybe add another if statement checking whether there is actually a piece in the location getting jumped
                            //Finally deleting the blackChecker
                            var toRemove = blackMen.reduce(function(foundIndex, piece, index) {
                                if (!foundIndex && piece.x === xLocationRemoving && piece.y === yLocationRemoving) {
                                    return index
                                } else {
                                    return foundIndex
                                }
                            }, null)

                            if (toRemove != null) {
                                blackMen.splice(toRemove, 1)
                            }
                        }
                        //Finally completing move
                        if(finalCoordinates.moveToCoordinate[position].coordinate.y == 10){
                            redMen[n].king = true;
                        }
                        redMen[n].x=finalCoordinates.moveToCoordinate[position].coordinate.x;
                        redMen[n].y=finalCoordinates.moveToCoordinate[position].coordinate.y;
                        break;
                    }
                }
            }
            //odd valued row calculation
        } else {
            if (finalCoordinates.moveFromCoordinate[position].coordinate.x ==5 ) {
                for(var n=0;n<redMen.length;n++){
                    //if a match is found in the red checker set
                    if(finalCoordinates.moveFromCoordinate[position].coordinate.x == redMen[n].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == redMen[n].y){
                        //if I jumped a guy, delete him
                        if( (finalCoordinates.moveToCoordinate[position].coordinate.y == finalCoordinates.moveFromCoordinate[position].coordinate.y +2) &&
                            ((finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x+1)||
                                (finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x-1)))
                        {
                            //Deleting Captured Men
                            var direction = finalCoordinates.moveToCoordinate[position].coordinate.x - finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            var xLocationRemoving;
                            var yLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.y +1;
                            if(direction>0){
                                //Direction is to right
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x+1;
                            }else{
                                //Direction is to left
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            }
                            //Maybe add another if statement checking whether there is actually a piece in the location getting jumped
                            //Finally deleting the blackChecker
                            var toRemove = blackMen.reduce(function(foundIndex, piece, index) {
                                if (!foundIndex && piece.x === xLocationRemoving && piece.y === yLocationRemoving) {
                                    return index
                                } else {
                                    return foundIndex
                                }
                            }, null)

                            if (toRemove != null) {
                                blackMen.splice(toRemove, 1)
                            }
                        }
                        //Finally completing move
                        if(finalCoordinates.moveToCoordinate[position].coordinate.y == 10){
                            redMen[n].king = true;
                        }

                        redMen[n].x=finalCoordinates.moveToCoordinate[position].coordinate.x;
                        redMen[n].y=finalCoordinates.moveToCoordinate[position].coordinate.y;
                        break;
                    }
                }
            } else {
                for(var n=0;n<redMen.length;n++){
                    //if a match is found in the red checker set
                    if(finalCoordinates.moveFromCoordinate[position].coordinate.x == redMen[n].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == redMen[n].y){
                        //if I jumped a guy, delete him
                        if( (finalCoordinates.moveToCoordinate[position].coordinate.y == finalCoordinates.moveFromCoordinate[position].coordinate.y +2) &&
                            ((finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x+1)||
                                (finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x-1)))
                        {
                            //Deleting Captured Men
                            var direction = finalCoordinates.moveToCoordinate[position].coordinate.x - finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            var xLocationRemoving;
                            var yLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.y +1;
                            if(direction>0){
                                //Direction is to right
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x+1;
                            }else{
                                //Direction is to left
                                xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                            }
                            //Maybe add another if statement checking whether there is actually a piece in the location getting jumped
                            //Finally deleting the blackChecker
                            var toRemove = blackMen.reduce(function(foundIndex, piece, index) {
                                if (!foundIndex && piece.x === xLocationRemoving && piece.y === yLocationRemoving) {
                                    return index
                                } else {
                                    return foundIndex
                                }
                            }, null)

                            if (toRemove != null) {
                                blackMen.splice(toRemove, 1)
                            }
                        }
                        //Finally completing move
                        if(finalCoordinates.moveToCoordinate[position].coordinate.y == 10){
                            redMen[n].king = true;
                        }
                        redMen[n].x=finalCoordinates.moveToCoordinate[position].coordinate.x;
                        redMen[n].y=finalCoordinates.moveToCoordinate[position].coordinate.y;
                        break;
                    }
                }
            }

        }
//The red checkers move section above can be represented as the black checker move is represented below
    }else{
        for(var n=0;n<blackMen.length;n++){
            //if a match is found in the red checker set
            if(finalCoordinates.moveFromCoordinate[position].coordinate.x == blackMen[n].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == blackMen[n].y){
                //if I jumped a guy, delete him
                if( (finalCoordinates.moveToCoordinate[position].coordinate.y == finalCoordinates.moveFromCoordinate[position].coordinate.y -2) &&
                    ((finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x-1)||
                        (finalCoordinates.moveToCoordinate[position].coordinate.x == finalCoordinates.moveFromCoordinate[position].coordinate.x+1)))
                {

                    //Deleting Captured Men
                    var direction = finalCoordinates.moveToCoordinate[position].coordinate.x - finalCoordinates.moveFromCoordinate[position].coordinate.x;
                    var xLocationRemoving;
                    var yLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.y -1;
                    if(even==true){
                        if(direction<0){
                            //Direction is to left
                            xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x-1;
                        }else{
                            //Direction is to right
                            xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                        }
                    }else{
                        if(direction<0){
                            //Direction is to left
                            xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x;
                        }else{
                            //Direction is to right
                            xLocationRemoving = finalCoordinates.moveFromCoordinate[position].coordinate.x+1;
                        }
                    }
                    //Maybe add another if statement checking whether there is actually a piece in the location getting jumped
                    //Finally deleting the blackChecker
                    var toRemove = redMen.reduce(function(foundIndex, piece, index) {
                        if (!foundIndex && piece.x === xLocationRemoving && piece.y === yLocationRemoving) {
                            return index
                        } else {
                            return foundIndex
                        }
                    }, null)

                    if (toRemove != null) {
                        redMen.splice(toRemove, 1)
                    }
                }

                if(finalCoordinates.moveToCoordinate[position].coordinate.y == 1){
                    blackMen[n].king = true;
                }
                //Finally completing move
                blackMen[n].x=finalCoordinates.moveToCoordinate[position].coordinate.x;
                blackMen[n].y=finalCoordinates.moveToCoordinate[position].coordinate.y;
                break;
            }
        }
    }
    //may not need to return anything..look into later
    return {
        redMen: redMen,
        blackMen: blackMen
            }
}













function isRedChecker(redMen, blackMen, finalCoordinates, position){
    for(var t=0; t< redMen.length;t++) {
        if (finalCoordinates.moveFromCoordinate[position].coordinate.x == redMen[t].x && finalCoordinates.moveFromCoordinate[position].coordinate.y == redMen[t].y) {
            return true;
        }

    }
    return false;
}

//Now that i've written it, I dont think whether it is even matters
function evenOrOdd(finalCoordinates, position){
    if(finalCoordinates.moveFromCoordinate[position].coordinate.y == 2 ||finalCoordinates.moveFromCoordinate[position].coordinate.y == 4||
        finalCoordinates.moveFromCoordinate[position].coordinate.y == 6||finalCoordinates.moveFromCoordinate[position].coordinate.y == 8||
    finalCoordinates.moveFromCoordinate[position].coordinate.y == 10){
        return true;
    }
    return false;
}



function movePieces(redMen, blackMen, finalCoordinates)
{

    for(var w=0; w< finalCoordinates.moveFromCoordinate.length; w++){
        if(isLegalMove(redMen, blackMen, finalCoordinates,w ) == true){
            //Current board
            var test = makeMove(redMen, blackMen, finalCoordinates,w);
        }
        //Return some type of error message if the move cannot be made
    }
    //test contains redMen and blackMen
    return test;
}

function isEmpty(xPosition, yPosition, blackMen, redMen)
{
    //added to check for avoid error on out of bounds...
    if(xPosition<1 ||xPosition>5 ||yPosition<1 || yPosition>10){
        return false;
    }
    for (var i = 0; i < blackMen.length; i++) {
        if (xPosition == blackMen[i].x && yPosition == blackMen[i].y) {
            return false;
        }
    }

    for (var j = 0; j < redMen.length; j++) {
        if (xPosition == redMen[j].x && yPosition == redMen[j].y) {
            return false;
        }
    }
    return true;
}

function isLegalMove(redMen, blackMen, finalCoordinates, position)
{
    if(isEmpty(finalCoordinates.moveToCoordinate[position].coordinate.x,finalCoordinates.moveToCoordinate[position].coordinate.y,blackMen,redMen)==true){
        return true;
    }
    else return false;
}


//Convert a number to a coordinate
function singleNumberToXY(number, boardWidth)
{
    var coordinate = new Object();
    if((number !==5) && (number !==10)&&(number !==15)&&(number !==20)&&(number !==25)&&(number !==30)&&(number !==35)&&(number !==40)&&(number !==45)&&(number !==50)){
        coordinate.x = number % boardWidth;
    }else{
        coordinate.x = 5;
    }

    coordinate.y = ((number - coordinate.x) / boardWidth)+1;
    return {
        coordinate: coordinate
    }
}
/*
 *Takes a set of moves and converts to two separate arrays
 */
function convertToCoordinate(moves)
{

    var moveFromCoordinate = [];
    var moveToCoordinate = new Array;
    for(var t=0;t<moves.length;t++){
        moveFromCoordinate.push(singleNumberToXY(moves[t][0],5));
        moveToCoordinate.push(singleNumberToXY(moves[t][1],5));
 //console.log(moves[t][0]+ "--" +moveFromCoordinate[t].coordinate.x + ","+ moveFromCoordinate[t].coordinate.y +"   !---------!   "+moves[t][1]+"--"+ moveToCoordinate[t].coordinate.x+","+moveToCoordinate[t].coordinate.y);
    }


    return{
        moveFromCoordinate: moveFromCoordinate,
        moveToCoordinate: moveToCoordinate
    }
}


function xyToSingle(x,y,boardWidth){
    var singleNumber;

    singleNumber= ((y-1)*boardWidth)+x;

    return singleNumber;
}

/*
function compare(a, b) {
    if (a is less than b by some ordering criterion)
    return -1;
    if (a is greater than b by the ordering criterion)
    return 1;
    // a must be equal to b
    return 0;
}


*/

function regularRedMove(blackMen,redMen,checkerPiece,indexing){
    var redMoves =[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object() ;
    var secondCoordinate = new Object();
    if(yPos == 2||yPos == 4||yPos == 6||yPos == 8||yPos == 10){
        if(isEmpty(xPos-1,yPos+1,blackMen,redMen)){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos+1;
            redMoves.push(newCoordinate);
        }
        if(isEmpty(xPos,yPos+1,blackMen,redMen)){
            secondCoordinate.x= xPos;
            secondCoordinate.y= yPos+1;
            redMoves.push(secondCoordinate);
        }
    }else{
        if(isEmpty(xPos+1,yPos+1,blackMen,redMen)){
            newCoordinate.x= xPos+1;
            newCoordinate.y= yPos+1;
            redMoves.push(newCoordinate);
        }
        if(isEmpty(xPos,yPos+1,blackMen,redMen)){
            secondCoordinate.x= xPos;
            secondCoordinate.y= yPos+1;
            redMoves.push(secondCoordinate);
        }
    }

    return redMoves

}

function regularBlackMove(blackMen,redMen,checkerPiece,indexing){
    var blackMoves =[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object();
    var secondCoordinate = new Object();
    if(yPos == 2||yPos == 4||yPos == 6||yPos == 8||yPos == 10){
        if(isEmpty(xPos-1,yPos-1,blackMen,redMen)){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos-1;
            blackMoves.push(newCoordinate);
        }
        if(isEmpty(xPos,yPos-1,blackMen,redMen)){
            secondCoordinate.x= xPos;
            secondCoordinate.y= yPos-1;
            blackMoves.push(secondCoordinate);
        }
    }else{
        if(isEmpty(xPos+1,yPos-1,blackMen,redMen)){
            newCoordinate.x= xPos+1;
            newCoordinate.y= yPos-1;
            blackMoves.push(newCoordinate);
        }
        if(isEmpty(xPos,yPos-1,blackMen,redMen)) {
            secondCoordinate.x = xPos;
            secondCoordinate.y = yPos - 1;
            blackMoves.push(secondCoordinate);
        }
    }
    return blackMoves

}

function kingSingleCheck(blackMen, redMen, checkerPiece,indexing){
    var kingMoves=[];
    var xPos = checkerPiece.x;
    var yPos = checkerPiece.y;
    var newCoordinate = new Object();
    var secondCoordinate = new Object();
    var thirdCoordinate = new Object();
    var fourthCoordinate = new Object();
    //checking whether on even or odd row
    if(yPos == 2||yPos == 4||yPos == 6||yPos == 8||yPos == 10){
        //Checking UP Diagonal Left
        if(isEmpty(xPos-1,yPos-1,blackMen,redMen)){
            newCoordinate.x= xPos-1;
            newCoordinate.y= yPos-1;
            kingMoves.push(newCoordinate);
        }
        //check UP Diagonal Right
        if(isEmpty(xPos,yPos-1,blackMen,redMen)){
            secondCoordinate.x= xPos;
            secondCoordinate.y= yPos-1;
            kingMoves.push(secondCoordinate);
        }
        //Checking Down Diagonal Left
        if(isEmpty(xPos-1,yPos+1,blackMen,redMen)){
            thirdCoordinate.x= xPos-1;
            thirdCoordinate.y= yPos+1;
            kingMoves.push(thirdCoordinate);
        }
        //Checking Down Diagonal Right
        if(isEmpty(xPos,yPos+1,blackMen,redMen)){
            fourthCoordinate.x= xPos;
            fourthCoordinate.y= yPos+1;
            kingMoves.push(fourthCoordinate);
        }
    }else {
        //Checking FROM Odd ROWS
        //Checking UP Diagonal Left
        if(isEmpty(xPos,yPos-1,blackMen,redMen)){
            newCoordinate.x= xPos;
            newCoordinate.y= yPos-1;
            kingMoves.push(newCoordinate);
        }
        //check UP Diagonal Right
        if(isEmpty(xPos+1,yPos-1,blackMen,redMen)){
            secondCoordinate.x= xPos+1;
            secondCoordinate.y= yPos-1;
            kingMoves.push(secondCoordinate);
        }
        //Checking Down Diagonal Left
        if(isEmpty(xPos,yPos+1,blackMen,redMen)){
            thirdCoordinate.x= xPos;
            thirdCoordinate.y= yPos+1;
            kingMoves.push(thirdCoordinate);
        }
        //Checking Down Diagonal Right
        if(isEmpty(xPos+1,yPos+1,blackMen,redMen)){
            fourthCoordinate.x= xPos+1;
            fourthCoordinate.y= yPos+1;
            kingMoves.push(fourthCoordinate);
        }
    }
    return kingMoves;
}

/*
 *   Reads in the file as a 2d matrix of FROM and TO moves
 */
function readMoves(file)
{
    var text;
    var lines = new Array();
    var moves = new Array();
    var fs = require('fs'), filename = file;

    text = fs.readFileSync(filename);
    lines = text.toString().split("\n");

    for (var r = 0; r < lines.length; r++) {
        moves[r] = lines[r].split(",");
        
        for (var c = 0; c < moves[r].length; c++){
        	moves[r][c] = parseInt( moves[r][c] );
        }
    }
    return moves;
}

/*
 *  Display the FROM and TO moves of the 2d Matrix
 */
function displayMoves(moves) {
    for (var m = 0; m < moves.length; m++) {
        console.log(moves[m][0] + "\t-->\t" + moves[m][1]);
    }


}