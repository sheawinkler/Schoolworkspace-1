/**
 * 
 */


var helpers = require('./helpers');
var part01 = require('./csce322a02p01');
var part02 = require('./csce322a02p02');

var moves = helpers.readMoves('movesTest.csv');
var ordinary = part01.movesOrdinary(moves);
var single = part02.movesCaptureSingle(moves);


//var print = helpers.displayMoves(moves);

for( var space = 1; space <= 50; space++ ){
    console.log( space + "\t:" + ordinary(space));
}


for( var space = 1; space <= 50; space++ ){
    console.log( space + "\t:" + single(space));
}


