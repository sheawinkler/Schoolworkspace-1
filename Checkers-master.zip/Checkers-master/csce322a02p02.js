/**
 * 
 */
var helpers = require('./helpers');
var part01 = require('./csce322a02p01');

exports.movesCaptureSingle = function(moves){
    /*
      This method should take the moves that have already been made in the game
      and return a function that, given the location of a piece on the board,
      returns a list of moves that the piece can make (accounting for slides and
      single valid jumps)
    */
    var initializing = helpers.initializeTable(moves);
    //action =test which contains redMen and blackMen
    var action = helpers.movePieces(initializing.redMen,initializing.blackMen, initializing.finalCoordinates);


        //finalList is an array containing the individual checker[0] and the possible moves[]
        var finalList = [];


        for (var b = 0; b < action.redMen.length; b++) {
            var tempContainer = new Object();
            tempContainer.checker = action.redMen[b];
            tempContainer.checkerLocation = [];
            tempContainer.PossibleMoveLocations = [];

            if (action.redMen[b].king == true) {
                //Possible King List
                tempContainer.possibleMoves = helpers.kingJump(action.blackMen, action.redMen, action.redMen[b], b)
                finalList.push(tempContainer);

            } else {
                tempContainer.possibleMoves = helpers.redJump(action.blackMen, action.redMen, action.redMen[b], b);
                finalList.push(tempContainer);
            }


        }


        for (var v = 0; v < action.blackMen.length; v++) {
            var tempContainer = new Object();
            tempContainer.checker = action.blackMen[v];
            tempContainer.checkerLocation = [];
            tempContainer.PossibleMoveLocations = [];

            if (action.blackMen[v].king == true) {
                //Possible King List
                tempContainer.possibleMoves = helpers.kingJump(action.blackMen, action.redMen, action.blackMen[v], v)
                finalList.push(tempContainer);

            } else {
                tempContainer.possibleMoves = helpers.blackJump(action.blackMen, action.redMen, action.blackMen[v], v);
                finalList.push(tempContainer);
            }

        }


        //Sort Final List by position, first converting each possible move back to a single value
        for (var p = 0; p < finalList.length; p++) {

            //Converting the CheckerLocation to a single Digit
            finalList[p].checkerLocation.push(helpers.xyToSingle(finalList[p].checker.x, finalList[p].checker.y, 5));
            if (finalList[p].possibleMoves.length > 0) {
                for (var m = 0; m < finalList[p].possibleMoves.length; m++) {

                    finalList[p].PossibleMoveLocations.push(helpers.xyToSingle(finalList[p].possibleMoves[m].x, finalList[p].possibleMoves[m].y, 5));
                }
            }
        }

        /*
        console.log("_______________________________________________________________");
        console.log("_______________________________________________________________");
        console.log("NEW FORM");
        console.log("PRINTING THE JUMP MAN MOVES NOW");


        //Printing to console

        */


    finalList.sort(function(obj1, obj2) {
        // Ascending: first age less than the previous
        return obj1.checkerLocation - obj2.checkerLocation;
    });

/*
    for (var c = 0; c < finalList.length; c++) {
        console.log(finalList[c]);

    }
*/
    var myList = new Array(50);
    var dummyObject = new Object();
    dummyObject.checkerLocation=[];
    dummyObject.PossibleMoveLocations=[];

    for(var p=0;p<myList.length;p++){
        for(var k=0;k<finalList.length;k++){
                if(finalList[k].checkerLocation == p){
                    myList[p] = finalList[k];
                    break;
                }
         }
    }
    //Now i have a list called my list with elements in respective position and undefined elsewhere
    for(var e=0;e<myList.length;e++){
        if(typeof myList[e]==="undefined"){
            myList[e] =dummyObject;
        }

    }



/*
    console.log("NEW Moves");
    for (var c = 0; c < myList.length; c++) {
        console.log(myList[c]);

    }
*/
/*
    console.log("Jump Moves");
           for (var c = 0; c < finalList.length; c++) {
            console.log(finalList[c]);

    }


*/


    var singleMoves = part01.movesOrdinary(moves);
    /*
    for( var space = 1; space <= 50; space++ ){
        console.log( space + "\t:" + singleMoves(space));
    }
*/


        var possibleLocationsJump = [];
        for (var g = 0; g < myList.length; g++) {
            possibleLocationsJump[g] = myList[g].PossibleMoveLocations;
            //possibleLocationsJump[g].push(singleMoves(g));
            //console.log("PRINTING THE EXTRACTED MOVES");
           // console.log(possibleLocationsJump[g]);
        }

    var tempHolder =[];

    for( var space = 0; space < possibleLocationsJump.length; space++ ){
        tempHolder[space] = singleMoves(space);
    }

    console.log(possibleLocationsJump);


    for( var space = 0; space < possibleLocationsJump.length; space++ ){
        possibleLocationsJump[space] = (tempHolder[space]);
    }

    possibleLocationsJump.concat(tempHolder);
/*
    for( var space = 0; space < tempHolder.length; space++ ){

      console.log(tempHolder[space]);
    }
*/


    function single(space) {

        if(possibleLocationsJump[space] != undefined) {
            return possibleLocationsJump[space];
        }else
            possibleLocationsJump[space] = [];
            return possibleLocationsJump[space];


    }
    return single;


}