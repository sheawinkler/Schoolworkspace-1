/**
 * 
 */

exports.movesCaptureGeneral = function(moves){
    /*
      This method should take the moves that have already been made in the game
      and return a function that, given the location of a piece on the board,
      returns a list of moves that the piece can make (accounting for slides and
      a general number of valid jumps)
    */
}